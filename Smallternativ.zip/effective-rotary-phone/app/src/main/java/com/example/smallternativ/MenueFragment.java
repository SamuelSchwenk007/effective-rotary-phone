package com.example.smallternativ;

import androidx.fragment.app.Fragment;

public class MenueFragment extends Fragment {
}
