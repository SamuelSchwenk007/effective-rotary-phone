package com.example.smallternativ;

public class EinstellungenActivity {
}
