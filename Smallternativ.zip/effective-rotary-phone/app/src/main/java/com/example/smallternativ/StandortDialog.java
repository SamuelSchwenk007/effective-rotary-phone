package com.example.smallternativ;

import androidx.fragment.app.DialogFragment;

public class StandortDialog extends DialogFragment {
}
