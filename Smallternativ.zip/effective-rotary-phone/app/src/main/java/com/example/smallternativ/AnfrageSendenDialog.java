package com.example.smallternativ;

import androidx.fragment.app.DialogFragment;

public class AnfrageSendenDialog extends DialogFragment {
}
