package com.example.smallternativ;

import androidx.fragment.app.Fragment;

public class KategorienFragment extends Fragment {
}
