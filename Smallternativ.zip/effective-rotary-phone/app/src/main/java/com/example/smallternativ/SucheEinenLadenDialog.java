package com.example.smallternativ;

public class SucheEinenLadenDialog {
}
