package com.example.smallternativ;

import androidx.fragment.app.Fragment;

public class AnfrageDetailsFragment extends Fragment {
}
